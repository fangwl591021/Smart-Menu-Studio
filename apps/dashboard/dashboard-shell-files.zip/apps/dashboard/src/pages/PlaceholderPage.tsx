interface PlaceholderPageProps {
  title: string;
}

export default function PlaceholderPage({ title }: PlaceholderPageProps) {
  return (
    <div>
      <h1 className="font-serif-tc text-lg text-ink">{title}</h1>
      <div className="mt-6 flex h-64 items-center justify-center rounded-xl border border-dashed border-line text-sm text-gray-400">
        {title} 模組尚未建置
      </div>
    </div>
  );
}

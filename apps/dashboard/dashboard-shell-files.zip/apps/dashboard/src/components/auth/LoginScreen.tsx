import { Sparkles } from 'lucide-react';

interface LoginScreenProps {
  onLogin?: () => void;
}

export default function LoginScreen({ onLogin }: LoginScreenProps) {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: 接上 POST /api/auth/login（Better Auth）
    onLogin?.();
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-paper px-4">
      <div className="w-full max-w-sm">
        <div className="mb-8 text-center">
          <div className="mx-auto mb-4 flex h-11 w-11 items-center justify-center rounded-xl bg-ink">
            <Sparkles className="h-5 w-5 text-jade" />
          </div>
          <h1 className="font-serif-tc text-xl text-ink">Smart Menu Studio</h1>
          <p className="mt-1 text-sm text-gray-500">登入你的 Workspace</p>
        </div>

        <form
          onSubmit={handleSubmit}
          className="rounded-2xl border border-line bg-white p-6"
        >
          <label htmlFor="email" className="mb-1.5 block text-xs text-gray-500">
            電子郵件
          </label>
          <input
            id="email"
            type="email"
            required
            placeholder="name@company.com"
            className="mb-4 w-full rounded-lg border border-line px-3 py-2.5 text-sm text-ink outline-none focus:border-ink"
          />

          <label htmlFor="password" className="mb-1.5 block text-xs text-gray-500">
            密碼
          </label>
          <input
            id="password"
            type="password"
            required
            placeholder="••••••••"
            className="mb-2 w-full rounded-lg border border-line px-3 py-2.5 text-sm text-ink outline-none focus:border-ink"
          />

          <div className="mb-5 text-right">
            <button type="button" className="text-xs text-gray-500 hover:text-ink">
              忘記密碼？
            </button>
          </div>

          <button
            type="submit"
            className="w-full rounded-lg bg-ink py-2.5 text-sm font-medium text-white"
          >
            登入
          </button>

          <div className="my-4 flex items-center gap-3">
            <div className="h-px flex-1 bg-line" />
            <span className="text-xs text-gray-500">或</span>
            <div className="h-px flex-1 bg-line" />
          </div>

          <button
            type="button"
            className="w-full rounded-lg border border-line py-2.5 text-sm text-ink"
          >
            使用 Google 登入
          </button>
        </form>

        <p className="mt-5 text-center text-xs text-gray-500">
          還沒有帳號？<span className="text-ink">建立 Workspace</span>
        </p>
      </div>
    </div>
  );
}

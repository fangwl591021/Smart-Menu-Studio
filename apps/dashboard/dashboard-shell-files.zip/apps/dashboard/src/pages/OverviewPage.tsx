import { Check } from 'lucide-react';
import { navItems, setupChecklist } from '../lib/mock-data';
import { useTenant } from '../lib/tenant-context';

export default function OverviewPage() {
  const { activeBrand } = useTenant();
  const doneCount = setupChecklist.filter((c) => c.done).length;

  return (
    <div>
      <div className="mb-6">
        <h1 className="font-serif-tc text-lg text-ink">總覽</h1>
        <p className="mt-1 text-sm text-gray-500">{activeBrand.name} · Phase 0 設定進度</p>
      </div>

      <div className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
        {navItems.slice(1).map((item) => {
          const Icon = item.icon;
          return (
            <div key={item.key} className="rounded-xl border border-line bg-white p-4">
              <Icon className="mb-3 h-4 w-4 text-gray-500" />
              <p className="text-sm text-ink">{item.label}</p>
              <p className="mt-0.5 text-xs text-gray-500">尚未設定</p>
            </div>
          );
        })}
      </div>

      <div className="rounded-xl border border-line bg-white p-5">
        <div className="mb-4 flex items-center justify-between">
          <p className="text-sm font-medium text-ink">完成設定流程</p>
          <span className="font-mono text-xs text-gray-500">
            {doneCount}/{setupChecklist.length}
          </span>
        </div>
        <div className="space-y-2.5">
          {setupChecklist.map((item) => (
            <div key={item.label} className="flex items-center gap-2.5">
              <div
                className={`flex h-4 w-4 flex-shrink-0 items-center justify-center rounded-full ${
                  item.done ? 'bg-jade-soft' : 'border border-line'
                }`}
              >
                {item.done && <Check className="h-2.5 w-2.5 text-jade" />}
              </div>
              <span className={`text-sm ${item.done ? 'text-ink' : 'text-gray-500'}`}>
                {item.label}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

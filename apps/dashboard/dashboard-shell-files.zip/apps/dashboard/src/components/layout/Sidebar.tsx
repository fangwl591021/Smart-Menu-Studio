import { Sparkles, ChevronLeft, ChevronRight } from 'lucide-react';
import { navItems, type NavKey } from '../../lib/mock-data';

interface SidebarProps {
  activeNav: NavKey;
  onNavChange: (key: NavKey) => void;
  collapsed: boolean;
  onToggleCollapsed: () => void;
}

export default function Sidebar({
  activeNav,
  onNavChange,
  collapsed,
  onToggleCollapsed,
}: SidebarProps) {
  return (
    <aside
      className="flex flex-shrink-0 flex-col bg-ink transition-all duration-200"
      style={{ width: collapsed ? 64 : 208 }}
    >
      <div className="flex h-14 items-center gap-2 border-b border-ink-line px-4">
        <div className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-lg bg-jade">
          <Sparkles className="h-3.5 w-3.5 text-white" />
        </div>
        {!collapsed && (
          <span className="truncate font-serif-tc text-sm text-white">Smart Menu</span>
        )}
      </div>

      <nav className="flex-1 space-y-0.5 px-2 py-3">
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = activeNav === item.key;
          return (
            <button
              key={item.key}
              type="button"
              onClick={() => onNavChange(item.key)}
              aria-current={active ? 'page' : undefined}
              className={`flex w-full items-center gap-3 rounded-lg px-2.5 py-2 text-left text-sm transition-colors ${
                active ? 'bg-ink-soft text-white' : 'text-ink-muted hover:bg-ink-soft/60'
              }`}
            >
              <Icon className="h-4 w-4 flex-shrink-0" />
              {!collapsed && <span className="truncate">{item.label}</span>}
            </button>
          );
        })}
      </nav>

      <button
        type="button"
        onClick={onToggleCollapsed}
        className="flex items-center gap-2 border-t border-ink-line px-4 py-3 text-xs text-ink-muted"
      >
        {collapsed ? <ChevronRight className="h-3.5 w-3.5" /> : <ChevronLeft className="h-3.5 w-3.5" />}
        {!collapsed && <span>收合選單</span>}
      </button>
    </aside>
  );
}

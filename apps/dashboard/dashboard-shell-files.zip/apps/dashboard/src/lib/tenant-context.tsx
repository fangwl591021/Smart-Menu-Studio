import { createContext, useContext, type ReactNode } from 'react';
import type { Brand } from './mock-data';

interface TenantContextValue {
  workspaceName: string;
  activeBrand: Brand;
}

const TenantContext = createContext<TenantContextValue | null>(null);

interface TenantProviderProps extends TenantContextValue {
  children: ReactNode;
}

export function TenantProvider({ workspaceName, activeBrand, children }: TenantProviderProps) {
  return (
    <TenantContext.Provider value={{ workspaceName, activeBrand }}>
      {children}
    </TenantContext.Provider>
  );
}

export function useTenant(): TenantContextValue {
  const ctx = useContext(TenantContext);
  if (!ctx) {
    throw new Error('useTenant 必須在 <TenantProvider> 內使用');
  }
  return ctx;
}

import type { LucideIcon } from 'lucide-react';
import {
  LayoutGrid,
  Building2,
  Users,
  MessageSquare,
  Image as ImageIcon,
  CreditCard,
  ScrollText,
  Laptop,
} from 'lucide-react';

export type NavKey =
  | 'overview'
  | 'brands'
  | 'members'
  | 'line'
  | 'assets'
  | 'plan'
  | 'audit'
  | 'devices';

export interface NavItem {
  key: NavKey;
  label: string;
  icon: LucideIcon;
}

// TODO: 之後改成從 packages/authorization 依角色權限動態產生
export const navItems: NavItem[] = [
  { key: 'overview', label: '總覽', icon: LayoutGrid },
  { key: 'brands', label: '品牌', icon: Building2 },
  { key: 'members', label: '成員', icon: Users },
  { key: 'line', label: 'LINE 官方帳號', icon: MessageSquare },
  { key: 'assets', label: '素材庫', icon: ImageIcon },
  { key: 'plan', label: '方案與授權', icon: CreditCard },
  { key: 'audit', label: '稽核紀錄', icon: ScrollText },
  { key: 'devices', label: '裝置管理', icon: Laptop },
];

export interface ChecklistItem {
  label: string;
  done: boolean;
}

// TODO: 之後改成從 GET /api/workspaces/:workspaceId 衍生的真實設定進度
export const setupChecklist: ChecklistItem[] = [
  { label: '註冊與登入', done: true },
  { label: '建立 Workspace', done: true },
  { label: '建立品牌', done: true },
  { label: '邀請成員', done: false },
  { label: '綁定 LINE 官方帳號', done: false },
  { label: '通過 Channel Token 驗證', done: false },
  { label: '選擇方案', done: false },
];

export interface Brand {
  id: string;
  name: string;
}

// TODO: 之後改成從 GET /api/workspaces/:workspaceId/brands 取得
export const mockBrands: Brand[] = [
  { id: 'brand_tony', name: 'TONY 行銷工作室' },
  { id: 'brand_beauty', name: '某某連鎖美容集團' },
  { id: 'brand_alliance', name: '品牌共好加速器' },
];

export interface AuditLogEntry {
  id: string;
  message: string;
}

// TODO: 之後改成從 GET /api/workspaces/:workspaceId/audit-logs 取得
export const recentAuditLogs: AuditLogEntry[] = [
  { id: 'log_1', message: '建立品牌「某某連鎖美容集團」' },
  { id: 'log_2', message: '邀請成員 alice@example.com' },
];

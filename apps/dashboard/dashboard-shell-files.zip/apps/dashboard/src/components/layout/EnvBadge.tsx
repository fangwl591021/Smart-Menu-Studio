export type Environment = 'production' | 'staging' | 'local';

const ENV_STYLES: Record<Environment, { dot: string; bg: string; text: string; label: string }> = {
  production: { dot: 'bg-jade', bg: 'bg-jade-soft', text: 'text-jade', label: 'PRODUCTION' },
  staging: { dot: 'bg-amber', bg: 'bg-amber-soft', text: 'text-amber', label: 'STAGING' },
  local: { dot: 'bg-gray-400', bg: 'bg-gray-100', text: 'text-gray-500', label: 'LOCAL' },
};

interface EnvBadgeProps {
  environment?: Environment;
}

export default function EnvBadge({ environment = 'production' }: EnvBadgeProps) {
  const style = ENV_STYLES[environment];
  return (
    <div className={`flex items-center gap-1.5 rounded-full px-2.5 py-1 ${style.bg}`}>
      <span className={`h-1.5 w-1.5 rounded-full ${style.dot}`} />
      <span className={`font-mono text-xs tracking-wide ${style.text}`}>{style.label}</span>
    </div>
  );
}

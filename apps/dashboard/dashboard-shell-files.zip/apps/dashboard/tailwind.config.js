/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#1B2333",
        "ink-soft": "#29334A",
        "ink-line": "#3A4460",
        "ink-muted": "#8C93A8",
        paper: "#F7F6F2",
        line: "#E4E1D8",
        jade: "#0E8F6F",
        "jade-soft": "#E4F3EE",
        amber: "#C97F0A",
        "amber-soft": "#FBEDD9",
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
        "serif-tc": ["'Noto Serif TC'", "serif"],
        mono: ["'IBM Plex Mono'", "monospace"],
      },
    },
  },
  plugins: [],
};

import { useState } from 'react';
import { ChevronDown, Plus } from 'lucide-react';
import EnvBadge from './EnvBadge';
import { mockBrands, type Brand } from '../../lib/mock-data';

interface TopbarProps {
  workspaceName: string;
  activeBrandId: string;
  onBrandChange: (id: string) => void;
  userInitials: string;
}

export default function Topbar({
  workspaceName,
  activeBrandId,
  onBrandChange,
  userInitials,
}: TopbarProps) {
  const [workspaceOpen, setWorkspaceOpen] = useState(false);

  return (
    <header className="flex h-14 flex-shrink-0 items-center justify-between border-b border-line bg-white px-5">
      <div className="flex items-center gap-4">
        <div className="relative">
          <button
            type="button"
            onClick={() => setWorkspaceOpen((open) => !open)}
            className="flex items-center gap-2 rounded-lg border border-line px-2.5 py-1.5 text-sm text-ink"
          >
            <span className="flex h-5 w-5 items-center justify-center rounded bg-ink text-[10px] text-white">
              {workspaceName.charAt(0)}
            </span>
            {workspaceName}
            <ChevronDown className="h-3.5 w-3.5 text-gray-500" />
          </button>

          {workspaceOpen && (
            <div className="absolute left-0 top-10 z-10 w-56 rounded-lg border border-line bg-white p-1 shadow-lg">
              <div className="rounded-md bg-paper px-2.5 py-2 text-sm text-ink">{workspaceName}</div>
              <div className="px-2.5 py-2 text-sm text-gray-500">切換 Workspace…</div>
              <div className="mt-1 flex items-center gap-1.5 border-t border-line px-2.5 py-2 text-sm text-ink">
                <Plus className="h-3.5 w-3.5" />
                建立新 Workspace
              </div>
            </div>
          )}
        </div>

        <div className="flex items-center gap-1.5">
          {mockBrands.map((brand: Brand) => {
            const active = activeBrandId === brand.id;
            return (
              <button
                key={brand.id}
                type="button"
                onClick={() => onBrandChange(brand.id)}
                className={`rounded-full px-3 py-1.5 text-xs ${
                  active ? 'bg-ink text-white' : 'border border-line text-gray-500'
                }`}
              >
                {brand.name}
              </button>
            );
          })}
        </div>
      </div>

      <div className="flex items-center gap-3">
        <EnvBadge environment="production" />
        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-amber-soft text-xs font-medium text-amber">
          {userInitials}
        </div>
      </div>
    </header>
  );
}

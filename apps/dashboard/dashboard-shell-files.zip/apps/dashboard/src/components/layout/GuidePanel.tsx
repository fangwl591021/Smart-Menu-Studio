import { ChevronLeft, ChevronRight, ShieldCheck, Clock, Sparkles } from 'lucide-react';
import { recentAuditLogs } from '../../lib/mock-data';

interface GuidePanelProps {
  open: boolean;
  onToggle: () => void;
  activeBrandName: string;
}

export default function GuidePanel({ open, onToggle, activeBrandName }: GuidePanelProps) {
  if (!open) {
    return (
      <button
        type="button"
        onClick={onToggle}
        aria-label="展開說明面板"
        className="flex w-8 flex-shrink-0 items-center justify-center border-l border-line bg-white"
      >
        <ChevronLeft className="h-4 w-4 text-gray-500" />
      </button>
    );
  }

  return (
    <aside className="w-72 flex-shrink-0 overflow-y-auto border-l border-line bg-white px-5 py-6">
      <div className="mb-5 flex items-center justify-between">
        <p className="text-sm font-medium text-ink">說明與狀態</p>
        <button type="button" onClick={onToggle} aria-label="收合說明面板">
          <ChevronRight className="h-4 w-4 text-gray-500" />
        </button>
      </div>

      <div className="mb-4 rounded-xl bg-paper p-4">
        <div className="mb-2 flex items-center gap-2">
          <ShieldCheck className="h-3.5 w-3.5 text-jade" />
          <span className="text-xs font-medium text-ink">租戶隔離</span>
        </div>
        <p className="text-xs leading-relaxed text-gray-500">
          目前僅顯示 {activeBrandName} 的資料，其他 Workspace 無法存取此頁面內容。
        </p>
      </div>

      <div className="mb-4">
        <p className="mb-2 text-xs font-medium text-gray-500">最近稽核紀錄</p>
        <div className="space-y-2">
          {recentAuditLogs.map((log) => (
            <div key={log.id} className="flex items-start gap-2 text-xs text-gray-500">
              <Clock className="mt-0.5 h-3 w-3 flex-shrink-0" />
              <span className="leading-relaxed">{log.message}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="rounded-xl border border-dashed border-line p-4">
        <div className="mb-1.5 flex items-center gap-1.5">
          <Sparkles className="h-3.5 w-3.5 text-amber" />
          <span className="text-xs font-medium text-ink">AI Guide</span>
        </div>
        <p className="text-xs leading-relaxed text-gray-500">
          Phase 1 開放後，這裡會依你目前的設定進度提供下一步建議。
        </p>
      </div>
    </aside>
  );
}

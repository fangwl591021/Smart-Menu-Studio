import { useState, type ReactNode } from 'react';
import Sidebar from './Sidebar';
import Topbar from './Topbar';
import GuidePanel from './GuidePanel';
import { mockBrands, type NavKey } from '../../lib/mock-data';
import { TenantProvider } from '../../lib/tenant-context';

interface AppShellProps {
  workspaceName: string;
  userInitials: string;
  activeNav: NavKey;
  onNavChange: (key: NavKey) => void;
  children: ReactNode;
}

export default function AppShell({
  workspaceName,
  userInitials,
  activeNav,
  onNavChange,
  children,
}: AppShellProps) {
  const [collapsed, setCollapsed] = useState(false);
  const [guideOpen, setGuideOpen] = useState(true);
  const [activeBrandId, setActiveBrandId] = useState(mockBrands[0].id);

  const activeBrand = mockBrands.find((b) => b.id === activeBrandId) ?? mockBrands[0];

  return (
    <div className="flex h-screen w-full bg-paper">
      <Sidebar
        activeNav={activeNav}
        onNavChange={onNavChange}
        collapsed={collapsed}
        onToggleCollapsed={() => setCollapsed((c) => !c)}
      />

      <div className="flex min-w-0 flex-1 flex-col">
        <Topbar
          workspaceName={workspaceName}
          activeBrandId={activeBrandId}
          onBrandChange={setActiveBrandId}
          userInitials={userInitials}
        />

        <TenantProvider workspaceName={workspaceName} activeBrand={activeBrand}>
          <div className="flex min-h-0 flex-1">
            <main className="flex-1 overflow-y-auto px-6 py-6">{children}</main>
            <GuidePanel
              open={guideOpen}
              onToggle={() => setGuideOpen((o) => !o)}
              activeBrandName={activeBrand.name}
            />
          </div>
        </TenantProvider>
      </div>
    </div>
  );
}

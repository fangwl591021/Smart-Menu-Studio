import { useState } from 'react';
import LoginScreen from './components/auth/LoginScreen';
import AppShell from './components/layout/AppShell';
import OverviewPage from './pages/OverviewPage';
import PlaceholderPage from './pages/PlaceholderPage';
import { navItems, type NavKey } from './lib/mock-data';

// TODO: 這個檔案暫時用 state 切換畫面。
// 接上 TanStack Router 後，LoginScreen / AppShell 底下的每個 nav item
// 應該各自變成一個 route，這裡的 useState 就可以整個拿掉。

export default function App() {
  const [isAuthed, setIsAuthed] = useState(false);
  const [activeNav, setActiveNav] = useState<NavKey>('overview');

  if (!isAuthed) {
    return <LoginScreen onLogin={() => setIsAuthed(true)} />;
  }

  const activeLabel = navItems.find((item) => item.key === activeNav)?.label ?? '';

  return (
    <AppShell
      workspaceName="TONY 行銷工作室"
      userInitials="TF"
      activeNav={activeNav}
      onNavChange={setActiveNav}
    >
      {activeNav === 'overview' ? <OverviewPage /> : <PlaceholderPage title={activeLabel} />}
    </AppShell>
  );
}
